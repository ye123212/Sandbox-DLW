from services.auth import login_user
from services.orders import create_order


def run():
    login_user("alice")
    create_order(101)
