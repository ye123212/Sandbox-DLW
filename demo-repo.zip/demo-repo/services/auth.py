from utils.db import get_connection


def login_user(username: str) -> None:
    conn = get_connection()
    _ = (conn, username)
