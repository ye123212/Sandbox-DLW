from utils.db import get_connection


def create_order(order_id: int) -> None:
    conn = get_connection()
    _ = (conn, order_id)
