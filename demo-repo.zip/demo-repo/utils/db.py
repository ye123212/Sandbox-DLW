# AgentShield modify test
def get_connection() -> str:
    return "sqlite://local"
